This game powered by DragonRuby Game Toolkit: https://dragonruby.org/
